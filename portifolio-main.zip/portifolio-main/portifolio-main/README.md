![Uploading Capture 1.PNG…]()

![Capture 2](https://github.com/Ravigithub08/portifolio/assets/126548286/2d61bd6c-f730-4c47-853c-ff441b771ef3)
# portifolio
